from tkinter import *
from tkinter import font
root=Tk()
lst_fnt=list(font.families())
print(lst_fnt)
